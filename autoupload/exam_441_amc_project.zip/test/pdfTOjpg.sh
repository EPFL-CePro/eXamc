#!/bin/bash

if ! command -v convert &> /dev/null
then
    echo "ImageMagick n'est pas installé. Installez-le avec 'sudo apt install imagemagick' (sur Ubuntu)."
    exit
fi

if [ -z "$1" ]; then
  echo "Usage : $0 <dossier contenant les PDF>"
  exit 1
fi

input_dir=$1

output_dir="$input_dir/jpeg_converted"
mkdir -p "$output_dir"

for pdf_file in "$input_dir"/*.pdf; do
  # Vérifier si le fichier existe
  if [ -f "$pdf_file" ]; then
    # Nom de base du fichier sans extension
    base_name=$(basename "$pdf_file" .pdf)
    
    echo "Conversion de $pdf_file en JPEG..."
    convert  "$pdf_file" "$output_dir/$base_name.jpg"
  fi
done

echo "Conversion terminée. Les fichiers JPEG sont dans le dossier : $output_dir"

